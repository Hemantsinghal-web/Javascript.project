// function buttonn()
// {
//     let btn = document.querySelector('.button')
//     btn.style.display="block"
//     // alert("Fas")
// }

function addnum()
{
    let number = document.querySelector('#number').value
    number.innerHTML =number+1;
    alert("sfsf")
}


function sub()
{
    let number = document.querySelector('#number').value
    number.innerHTML =number-1;
    alert("sfsf")
}


const datasubmit = () => {
    let userdata = {
        name : document.querySelector("#uname").value,
        
        psw : document.querySelector("#upsw").value,
        email : document.querySelector("#email").value
    }

    localStorage.setItem("userdata",JSON.stringify(userdata))
}



function check()
{
  
    let logindata = {
     name : document.querySelector("#uname").value,
     psw : document.querySelector("#upsw").value
    }


    
   let data = JSON.parse(localStorage.getItem('userdata'))
   
   if(data.name != logindata.name || data.psw != logindata.psw)
   {
    alert("user not found")
    return false
   }
  
}



function form()
{
    let fname = document.querySelector('#fname').value
    let lname = document.querySelector('#lname').value
    let contact = document.querySelector('#contact').value
    let email = document.querySelector('#email').value


    if(fname == '')
    {
        alert("Plese enter Name")
        document.querySelector('#fname').focus()
        return false
    }
    else if(lname == '')
    {
        alert("Please Enter name")
        document.querySelector('#lname').focus()
        return false
    }

    
    else if(contact == '')
    {
    alert("Plese enter contact")
    document.querySelector('#contact').focus()
    return false
    }



        else if(contact.length>10 || contact.length<10)
        {
        alert("Enter a valid number")
        document.querySelector('#contact').focus()
        return false
        }
        
        else if(email == '')
            {
                alert("Plese enter Email")
                document.querySelector('#email').focus()
                return false
            }
    
            else if(!(email.includes('@')))
            {
                alert("Enter a valid email")
                document.querySelector('#email').focus()
                return false
            }
}


function table_data()
{
    
}